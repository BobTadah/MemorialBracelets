<?php

use \Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Fooman_GoogleAnalyticsPlus',
    __DIR__
);
